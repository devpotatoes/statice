# Change Log

All notable changes to the "Statice" extension will be documented in this file.

## [Unreleased]


## [1.0.0] - 2024-04-08

- Initial release.